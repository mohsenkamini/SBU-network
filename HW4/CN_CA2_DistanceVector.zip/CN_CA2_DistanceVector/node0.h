void rtinit0();

void rtupdate0(struct rtpkt *rcvdpkt);

void linkhandler0(int linkid, int newcost);

void printdt0();
